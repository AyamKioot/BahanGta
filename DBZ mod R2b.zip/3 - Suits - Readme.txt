My mods doesn't includes ped models (suits), only in few cases, so, after installing the script 
that brings the powers you probably want to install a ped model to use the powers, this guide 
shows how to install peds in a very easy way:

https://www.youtube.com/watch?v=96GzYA69GmQ

After adding peds to game, it probably will crash due to game limits, to fix this, apply all steps of this guide:
https://gtaxscripting.blogspot.com/2019/05/gta-5-added-peds-limit-fix.html

Some Goku ped models to use:
https://www.gta5-mods.com/player/dragonball-super-broly-ini-files-included (https://www.patreon.com/TheDarthKnight/posts)
https://www.gta5-mods.com/player/dragon-ball-z-goku (https://www.patreon.com/quechus13)
https://www.gta5-mods.com/player/goku-from-dragon-ball-saga-all-in-1-add-on-replace (https://www.patreon.com/metagta)