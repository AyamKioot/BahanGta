Dragon Ball script mod by JulionIB (TJulioNIB)

https://www.youtube.com/watch?v=dO1q3sYRUag


General JulioNIB's mods setup guide:
https://gtaxscripting.blogspot.com/2020/09/gta-5-julionib-mods-setup-guide-oiv.html


Use OpenIV Package installer to install the .OIV files

Press Ctrl+D0 (the zero close to P key) to see the NIBMods spawn menu or Ctrl+N to see NIBMods Menu

More details in this blog post:
http://gtaxscripting.blogspot.com/2017/10/gta-v-dragon-ball-script-mod-work-in.html

Some Goku ped models to use:
https://www.gta5-mods.com/player/dragon-ball-z-goku (https://www.patreon.com/quechus13)
https://www.gta5-mods.com/player/goku-from-dragon-ball-saga-all-in-1-add-on-replace (https://www.patreon.com/metagta)


For manual setup (without openIV package installer) open the .oiv file with winzip or winrar (or any other file compressor)


############## Required plugins for my GTA V mods ############## 

-ScripthookV & ASI Loader:
http://www.dev-c.com/gtav/scripthookv/

-NIBSHDotNet (My custom version of ScripthookVDotNet v2.10.9):
https://www.patreon.com/posts/nibmods-menu-22783974

-OpenIV and OpenIV.asi may be needed too (to edit RPF files, add peds, etc.):
http://openiv.com/


############## Tutorials and guides ############## 

General Help:                         https://gtaxscripting.blogspot.com/2019/05/gta-5-modding-help.html
.NET scripts basic setup:             https://www.youtube.com/watch?v=l88lGn96E7U
.NET scripts .oiv files setup:        http://gtaxscripting.blogspot.com.br/2016/07/tut-installing-oiv-packages-in-gta-v.html
Addon Peds plugin setup guide:        https://www.youtube.com/watch?v=ILruXAv_JJg
Add peds guide:                       https://www.youtube.com/watch?v=Lkws32GUd7I
Add peds game crash/limit FIX:        https://www.youtube.com/watch?v=TmBLlb51KMM
Replace peds guide:                   https://www.youtube.com/watch?v=75Igq9J6jbw


############## Social media ############## 

Help me grow, share my links on your videos :)

https://www.youtube.com/user/GTAScripting
https://www.patreon.com/JulioNIB
https://www.facebook.com/GtaIVScripting
https://twitter.com/julionib